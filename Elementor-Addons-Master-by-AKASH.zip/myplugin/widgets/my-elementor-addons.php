<?php
namespace MyElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */
class MyElementorAddonsWidget extends Widget_Base {

	public function get_name() {
		return 'my-plugin';
	}

	public function get_title() {
		return __( 'My Plugin', 'my-plugin' );
	}

	public function get_icon() {
		return 'fa fa-facebook';
	}



}
